set_value() {
  value=$1
  path=$2
  if [[ -f $path ]]; then
    current_value="$(cat $path)"
    if [[ ! "$current_value" = "$value" ]]; then
      chmod 0664 "$path"
      echo "$value" > "$path"
    fi;
  fi;
}

lock_value () {
  if [[ -f $2 ]];then
    chmod 644 $2
    echo $1 > $2
    chmod 444 $2
  fi
}

dev_mount=/dev/$(cat /dev/urandom | tr -dc 'a-z_' | head -c 8; echo)
# hide_value /sys/module/task_turbo/parameters/feats [write_value]
hide_value() {
  if [[ -e "$1" ]]; then
    umount "$1" 2>/dev/null
    c_path="$dev_mount${1}"
    if [[ ! -f "$c_path" ]]; then
      mkdir -p "$c_path"
      rm -r "$c_path"
    fi
    cp -f "$1" "$c_path"
    if [[ "$2" != "" ]]; then
      set_value "$2" "$1"
    fi
    mount --bind "$c_path" "$1"
  else
    echo "$1" Not Found!
  fi
}

rmdir /dev/cpuset/background/untrustedapp
rmdir /dev/cpuset/foreground/boost

t_message=/sys/class/thermal/thermal_message
if [[ -f $t_message/cpu_limits ]]; then
  chmod 664 $t_message/cpu_limits
  for i in $(seq 0 7); do
    maxfreq=$(cat /sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq)
    echo cpu$i $maxfreq > $t_message/cpu_limits
  done
  chmod 444 $t_message/cpu_limits
fi
lock_value 0 $t_message/market_download_limit
lock_value 0 $t_message/modem_limit
lock_value 0 0 0 0 /sys/class/thermal/thermal_message/boost

lock_value 0 /sys/kernel/fpsgo/fbt/enable_ceiling
lock_value 0 /sys/module/mtk_fpsgo/parameters/perfmgr_enable

if [[ $(grep /proc/perfmgr/perf_ioctl /proc/mounts) == '' ]]; then
mount --bind /proc/perfmgr/xgff_boost_ioctl /proc/perfmgr/perf_ioctl
fi
chmod 444 /proc/perfmgr/global_reclaim

# echo 0 300000 2000000 > /proc/cpudvfs/cpufreq_debug
# echo 4 550000 2850000 > /proc/cpudvfs/cpufreq_debug
# echo 7 600000 3250000 > /proc/cpudvfs/cpufreq_debug
echo 0 > /proc/powerhal_cpu_ctrl/adpf_enable
umount /proc/powerhal_cpu_ctrl/perfserv_freq
echo '300000 2000000 550000 2850000 600000 3250000' > /proc/powerhal_cpu_ctrl/perfserv_freq
mount --bind /proc/powerhal_cpu_ctrl/adpf_enable /proc/powerhal_cpu_ctrl/perfserv_freq
# lock_value '3000000 3350000' /sys/module/mtk_fpsgo/parameters/cpus_limit
# lock_value 1 /sys/module/mtk_fpsgo/parameters/better_perf
stop touch_boost

chmod 444 /sys/kernel/fpsgo/fbt/fbt_attr_by_pid
chmod 444 /sys/kernel/fpsgo/fbt/fbt_attr_by_tid
lock_value 0 /sys/module/mtk_fpsgo/parameters/boost_affinity

# echo 1 > /sys/module/migt/parameters/force_reset_runtime
# lock_value 0 /sys/module/migt/parameters/enable_pkg_monitor
lock_value 1 /sys/module/migt/parameters/glk_disable
lock_value 0 /sys/module/migt/parameters/glk_fbreak_enable
lock_value 0 /sys/module/migt/parameters/force_cluster_sched_enable
lock_value -1 /sys/module/migt/parameters/render_prefer_cluster
lock_value -1 /sys/module/migt/parameters/vip_prefer_cluster
lock_value -1 /sys/module/migt/parameters/stask_prefer_cluster
lock_value -1 /sys/module/migt/parameters/ip_prefer_cluster
lock_value 0 /sys/module/migt/parameters/glk_freq_limit_start
set_value '0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0' /sys/module/migt/parameters/migt_ceiling_freq
set_value '0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0' /sys/module/migt/parameters/migt_freq
set_value 1 /sys/module/metis/parameters/reset_clus_affinity_uidlist
set_value 1 /sys/module/metis/parameters/reset_rebind_task
lock_value 0 /sys/module/metis/parameters/thermal_break_enable
lock_value 0 /sys/module/metis/parameters/is_break_enable
lock_value 0 /sys/module/metis/parameters/mi_freq_enable

metis=/sys/module/metis/parameters
for file in $metis/*enable*; do
  lock_value 0 $file
done
if [[ -d $metis ]]; then
  chmod -R 444 $metis
fi

# echo 1 > /sys/module/mtk_core_ctl/parameters/policy_enable
lock_value 1 /sys/devices/system/cpu/cpu4/core_ctl/enable
lock_value 3 /sys/devices/system/cpu/cpu4/core_ctl/max_cpus
lock_value 3 /sys/devices/system/cpu/cpu4/core_ctl/min_cpus
lock_value 0 /sys/devices/system/cpu/cpu4/core_ctl/enable

lock_value 1 /sys/devices/system/cpu/cpu7/core_ctl/enable
lock_value 1 /sys/devices/system/cpu/cpu7/core_ctl/max_cpus
lock_value 1 /sys/devices/system/cpu/cpu7/core_ctl/min_cpus
lock_value 0 /sys/devices/system/cpu/cpu7/core_ctl/enable

# vivo
if [[ -e /sys/module/vivo_board_info ]] || [[ -e /sys/module/vivo_display ]]; then
  stop vivo-vperf-hal-1-0
  stop vendor.vivoperfservice
  echo 0 > /proc/powerhal_cpu_ctrl/adpf_enable
  stop thermal_core
  stop thermald
  if [[ $(getprop vtools.thermal.disguise) != '1' ]]; then
    lock_value "MAX_TTJ 95000 90000 90000" /sys/kernel/thermal/max_ttj
    lock_value "TTJ 95000 90000 90000" /sys/kernel/thermal/ttj
  fi
fi

# Low Battery Throttling
echo "low_battery_throttling"
echo "Utest 0" > /sys/devices/platform/low-battery-throttling/low_battery_protect_ut
echo "stop 1"  > /sys/devices/platform/low-battery-throttling/low_battery_protect_stop
echo "bp_thl (battery percent)"
echo "Utest 0" > /sys/devices/platform/bp-thl/bp_thl_ut
echo "stop 1"  > /sys/devices/platform/bp-thl/bp_thl_stop

# dynamicc throttling / tas?
lock_value 0 /sys/kernel/fpsgo/fbt/powerRL_enable
# lock_value "0 0" /sys/kernel/fpsgo/fstb/fstb_debug
chmod 444 /sys/kernel/fpsgo/common/render_attr_params
chmod 444 /sys/kernel/fpsgo/common/render_attr_params_tid
chmod 444 /sys/kernel/fpsgo/common/render_info
chmod 444 /sys/kernel/fpsgo/common/render_info_params

lock_value 1 /proc/game_opt/disable_cpufreq_limit
lock_value 1 /sys/module/migt/parameters/glk_disable
lock_value 0 /sys/module/perfmgr/parameters/perfmgr_enable
lock_value 0 /sys/module/migt/parameters/glk_freq_limit_walt
lock_value 0 /sys/module/cpufreq_bouncing/parameters/enable
lock_value 0 /sys/devices/platform/soc/soc:oplus-omrg/oplus-omrg0/ruler_enable
lock_value 0 /proc/task_overload/skip_goplus_enabled
lock_value 0 /sys/module/mtk_fpsgo/parameters/cfp_onoff
lock_value 0 /proc/touch_boost/enable
stop vendor.oplus.ormsHalService-aidl-default

set_cpuset(){
  pgrep -f $1 | while read pid; do
    echo $pid > /dev/cpuset/$2/cgroup.procs
    ls /proc/$pid/task | while read tid
    do
      echo $tid > /dev/cpuset/$2/tasks
    done
  done
}

mkdir /dev/cpuset/top-app/7
echo 7 > /dev/cpuset/top-app/7/cpus
echo 0 > /dev/cpuset/top-app/7/mems

set_cpuset touch_report 'foreground'
set_cpuset surfaceflinger 'foreground'
set_cpuset system_server 'foreground'
set_cpuset update_engine 'top-app/7'
set_cpuset vendor.qti.hardware.display.composer-service 'foreground'

# The logd of K70U is too busy.
getprop | grep log.tag | while read row
do
  prop=$(echo $row | cut -f2 -d '[' | cut -f1 -d ']')
  setprop $prop E || resetprop $prop E
done


# k70u default 2
# resetprop --delete persist.sys.advanced_visual_release
